# Device & App Control Agent

## Overview
This Python agent simulates performing system-level tasks from a log file using basic logic and rewards.

## How It Works
- Reads tasks from `task_log.txt`
- Simulates actions like "Open file", "Mute audio", etc.
- Rewards itself for valid tasks
- Logs results in `reward_log.csv`

## Run Instructions
```bash
python main.py
```

## Files
- `main.py` — Entry point
- `agent.py` — Core agent logic
- `memory.py` — Saves reward log
- `task_log.txt` — Input task log
