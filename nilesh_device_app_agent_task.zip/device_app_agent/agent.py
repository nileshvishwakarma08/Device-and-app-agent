class Agent:
    def __init__(self):
        self.memory = []
        self.reward = 0

    def parse_task(self, line):
        if " - " in line:
            time, action = line.split(" - ", 1)
            return time.strip(), action.strip()
        return "Unknown", line.strip()

    def simulate_action(self, action):
        print(f"Simulating: {action}")
        if "Open file" in action or "Mute" in action or "Check" in action:
            return 2
        elif "Open response template" in action:
            return 1
        else:
            return -1

    def process_tasks(self, filepath):
        try:
            with open(filepath, "r") as file:
                for line in file:
                    time, action = self.parse_task(line)
                    reward = self.simulate_action(action)
                    self.memory.append((time, action, reward))
                    self.reward += reward
        except FileNotFoundError:
            print("task_log.txt not found.")
