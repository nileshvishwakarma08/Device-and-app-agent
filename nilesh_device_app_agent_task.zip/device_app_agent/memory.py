import csv

def log_memory(memory):
    with open('reward_log.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Time', 'Action', 'Reward'])
        for row in memory:
            writer.writerow(row)
