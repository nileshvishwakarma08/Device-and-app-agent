from agent import Agent
from memory import log_memory

def main():
    agent = Agent()
    agent.process_tasks("task_log.txt")
    log_memory(agent.memory)
    print("Total reward:", agent.reward)

if __name__ == "__main__":
    main()
